import './App.css';
import CreditTransferForm from './components/CreditTransferForm/CreditTransferForm';
import SuccessScreen from './components/SuccessScreen/SuccessScreen';
import Login from './components/Login/Login'; 
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/transfer" element={<CreditTransferForm />} />
          <Route path="/success" element={<SuccessScreen />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;


