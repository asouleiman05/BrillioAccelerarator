import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './CreditTransferForm.css';

const isValidIban = (iban) => {
  const ibanRegex = /^[A-Z]{2}[0-9A-Z]{13,30}$/; // Simple IBAN check
  return ibanRegex.test(iban.replace(/\s+/g, '').toUpperCase());
};


const CreditTransferForm = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    amount: '',
    description: '',
    debtorName: '',
    debtorIban: '',
    creditorName: '',
    creditorIban: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleCancel = () => {
    setFormData({
      amount: '',
      description: '',
      debtorName: '',
      debtorIban: '',
      creditorName: '',
      creditorIban: ''
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const amountValue = parseFloat(formData.amount);
    if (isNaN(amountValue) || amountValue <= 0) {
      alert("Amount must be greater than 0.");
      return;
    }
    if (!isValidIban(formData.debtorIban)) {
      alert("Invalid IBAN format for Sender's IBAN.");
      return;
    }
  
    if (!isValidIban(formData.creditorIban)) {
      alert("Invalid IBAN format for Recipient's IBAN.");
      return;
    }

    const txId = crypto.randomUUID().slice(0, 16);
    const uetr = crypto.randomUUID();
    const today = new Date();
    const intrBkSttlmtDt = `${String(today.getDate()).padStart(2, '0')}/${String(today.getMonth() + 1).padStart(2, '0')}/${today.getFullYear()}`;

    const requestBody = {
      settlementInfo: {
        settlementMethod: "CLRG"
      },
      chargeBearer: "DEBT",
      interbankSettlementDate: intrBkSttlmtDt,
      interbankSettlementAmount: {
        currencyCode: "EUR",
        value: parseFloat(formData.amount)
      },
      paymentIdentification: {
        endToEndIdentification: "NOTPROVIDED",
        transactionIdentification: txId,
        instructionIdentification: txId,
        uetr
      },
      instructingAgent: {
        financialInstitutionIdentification: {
          bicfi: "BANKSBIC"
        }
      },
      instructedAgent: {
        financialInstitutionIdentification: {
          bicfi: "TESTBICA"
        }
      },
      debtor: {
        name: formData.debtorName,
        postalAddress: {
          addressLine: ["N/A"]
        }
      },
      debtorAccount: {
        identification: {
          iban: formData.debtorIban
        }
      },
      debtorAgent: {
        financialInstitutionIdentification: {
          bicfi: "BANKSBIC"
        }
      },
      creditor: {
        name: formData.creditorName,
        postalAddress: {
          addressLine: ["N/A"]
        }
      },
      creditorAccount: {
        identification: {
          iban: formData.creditorIban
        }
      },
      creditorAgent: {
        financialInstitutionIdentification: {
          bicfi: "TESTBICA"
        }
      },
      remittanceInformation: {
        unstructured: [formData.description || "Payment"]
      }
    };

    try {
      const response = await fetch('https://aplonhub-brillio.pc14.eu/aplon-hub-api/cbpr/customer/credit/transfer', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(requestBody)
      });
      
      const data = await response.json();
   
      if (data.status === "OK") {
        navigate('/success', { state: { txRef: data.payload },replace: true });
      } else {
        alert("Error: " + (data.errorCode || "Unknown error"));
      }
    } catch (err) {
      alert("Request failed: " + err.message);
    }
  };

  return (
    <div className="form-container">
      <h2>Send New Credit Transfer</h2>
      <form onSubmit={handleSubmit}>
        <label>Amount (EUR)</label>
        <input name="amount" type="number" value={formData.amount} onChange={handleChange} required min="0.01"
  step="0.01" />

        <label>Description (Optional)</label>
        <textarea name="description" value={formData.description} onChange={handleChange} />

        <label>	Sender's Name</label>
        <input name="debtorName" value={formData.debtorName} onChange={handleChange} required />

        <label>Sender's IBAN</label>
        <input name="debtorIban" value={formData.debtorIban} onChange={handleChange} required />

        <label>	Recipient's Name</label>
        <input name="creditorName" value={formData.creditorName} onChange={handleChange} required />

        <label>Recipient's IBAN</label>
        <input name="creditorIban" value={formData.creditorIban} onChange={handleChange} required />

        <div className="button-group">
          <button type="button" onClick={handleCancel}>Cancel</button>
          <button type="submit">Send</button>
        </div>
      </form>
    </div>
  );
};

export default CreditTransferForm;

