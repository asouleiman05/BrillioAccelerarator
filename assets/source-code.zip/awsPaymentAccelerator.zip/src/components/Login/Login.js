import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../CreditTransferForm/CreditTransferForm.css';

const Login = () => {
  const [credentials, setCredentials] = useState({ email: '', password: '' });
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCredentials(prev => ({ ...prev, [name]: value }));
  };

  const handleLogin = (e) => {
    e.preventDefault();
    // Replace with real auth logic as needed
    if (credentials.email === 'admin@example.com' && credentials.password === 'admin') {
      navigate('/transfer');
    } else {
      alert('Invalid credentials');
    }
  };

  return (
    <div className="form-container">
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <label>Email ID</label>
        <input
          type="email"
          name="email"
          value={credentials.email}
          onChange={handleChange}
          required
        />

        <label>Password</label>
        <input
          type="password"
          name="password"
          value={credentials.password}
          onChange={handleChange}
          required
        />

        <div className="button-group">
          <button type="submit">Login</button>
        </div>
      </form>
    </div>
  );
};

export default Login;
