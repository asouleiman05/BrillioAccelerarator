import React, { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const SuccessScreen = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const txRef = location.state?.txRef;

  useEffect(() => {
    // Redirect to login if accessed directly or via browser back
    if (!txRef) {
      navigate('/', { replace: true });
    }
  }, [txRef, navigate]);

  return (
    <div className="success-screen">
      <h2>✅ Payment Created Successfully</h2>
      <p><strong>Transaction Reference:</strong> {txRef}</p>
      <p>  Please check your transaction details at{' '} 
      
  <a
  href="https://aplonhub-brillio.pc14.eu/cbpr?inOutInt=O"
  target="_blank"
  rel="noopener noreferrer"
>
  aplonHUB
</a>

  </p>
      <button onClick={() => navigate('/')}>Make Another Payment</button>
    </div>
  );
};

export default SuccessScreen;
